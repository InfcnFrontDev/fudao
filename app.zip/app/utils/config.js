const config = {
    appName: '福道健康环',
    appVersion: 'v1.0.3',

    // 页面加载延迟时间
	loadingDelayTime: 400,
};

export default config;