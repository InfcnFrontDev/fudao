'use strict';

export const CHAT_TYPE_USER = 'USER';
export const CHAT_TYPE_GROUP = 'GROUP';
